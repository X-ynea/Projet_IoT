#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int tomate;
    int sol;
    int temps;
    int frequence;
    float quantite;
    char input[50];
    char ligne[5];
    int cptLigne = 0;

    FILE *fichier1 = fopen("./Tomate.txt", "r");
    FILE *fichier2 = fopen("./Sol.txt", "r");
    FILE *fichier3 = fopen("./Temp.txt", "r");

    // Lecture du fichier Tomate.txt pour mettre la valeur dans "tomate"
    while (fgets(ligne, sizeof(ligne), fichier1) != NULL) {
        tomate = atoi(ligne);
    }

    // Lecture du fichier Sol.txt pour mettre la valeur dans "sol"
    while (fgets(ligne, sizeof(ligne), fichier2) != NULL) {
        sol = atoi(ligne);
    }
    
    // Lecture du fichier Temps.txt pour mettre la valeur dans "temps"
    while (fgets(ligne, sizeof(ligne), fichier3) != NULL) {
        temps = atoi(ligne);
    }


    // Mise à jour de fréquence et quantité
    if (sol == 1) {     // Argileux
        if (tomate == 1) {     // Coeur de boeuf
            switch (temps) {
                case 1 :     // Normal
                    frequence = 1;
                    quantite = 2.5;
                    break;
                case 2 :     // Humide
                    frequence = 1;
                    quantite = 1.5;
                    break;
                case 3 :     // Sec
                    frequence = 1;
                    quantite = 3;
                    break;
                case 4 :     // Canniculaire
                    frequence = 2;
                    quantite = 3.5;
                    break;
            }
            
        }

        if (tomate == 2) {     // Cerise
            switch (temps) {
                case 1 :     // Normal
                    frequence = 1;
                    quantite = 1.5;
                    break;
                case 2 :     // Humide
                    frequence = 1;
                    quantite = 1;
                    break;
                case 3 :     // Sec
                    frequence = 1;
                    quantite = 2;
                    break;
                case 4 :     // Canniculaire
                    frequence = 1;
                    quantite = 2.5;
                    break;
            }
        }

        if (tomate == 3) {     // Ananas
            switch (temps) {
                case 1 :     // Normal
                    frequence = 1;
                    quantite = 2.5;
                    break;
                case 2 :     // Humide
                    frequence = 1;
                    quantite = 1.5;
                    break;
                case 3 :     // Sec
                    frequence = 2;
                    quantite = 3.5;
                    break;
                case 4 :     // Canniculaire
                    frequence = 2;
                    quantite = 4.5;
                    break;
            }
        }
    }

    if (sol == 2) {     // Sablonneux
        if (tomate == 1) {     // Coeur de boeuf
            switch (temps) {
                case 1 :     // Normal
                    frequence = 1;
                    quantite = 2.5;
                    break;
                case 2 :     // Humide
                    frequence = 1;
                    quantite = 1.5;
                    break;
                case 3 :     // Sec
                    frequence = 2;
                    quantite = 3.5;
                    break;
                case 4 :     // Canniculaire
                    frequence = 2;
                    quantite = 4.5;
                    break;
            }
        }

        if (tomate == 2) {     // Cerise
            switch (temps) {
                case 1 :     // Normal
                    frequence = 1;
                    quantite = 2;
                    break;
                case 2 :     // Humide
                    frequence = 1;
                    quantite = 1;
                    break;
                case 3 :     // Sec
                    frequence = 2;
                    quantite = 3;
                    break;
                case 4 :     // Canniculaire
                    frequence = 2;
                    quantite = 4;
                    break;
            }
        }

        if (tomate == 3) {     // Ananas
            switch (temps) {
                case 1 :     // Normal
                    frequence = 1;
                    quantite = 3.5;
                    break;
                case 2 :     // Humide
                    frequence = 1;
                    quantite = 2;
                    break;
                case 3 :     // Sec
                    frequence = 2;
                    quantite = 4.5;
                    break;
                case 4 :     // Canniculaire
                    frequence = 2;
                    quantite = 5.5;
                    break;
            }
        }
    }

    
    fprintf(stdout, "%d,%.1f", frequence, quantite);
    //fprintf(stdout, "tomate : %d, sol : %d, temps : %d", tomate, sol, temps);


    // Ferme les fichiers
    fclose(fichier1);
    fclose(fichier2);
    fclose(fichier3);


    return 0;
}